<?php

/*
8- (2 pts.) caso: alumnos (get):
 Mostrar una tabla con todos los datos de los alumnos, incluida la foto.
*/

echo "<font size='3' color='blue'  face='verdana' style='font-weight:bold' <br>alumnos  <br> </font>";

Facultad::alumnos();


?>



