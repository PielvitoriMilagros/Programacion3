<?php 

//Ejercicio4:
echo "</br></br><strong>$Ap4</strong></br>";

	$sumaAp4=0;
	for($i=0;$sumaAp4<1000;$i++)
	{
		//echo "</br> Acumulada= ".$sumaAp4." + i= ".$i ;
		$sumaAp4=$sumaAp4+$i; 
		
	}
	echo "</br>Suma=".$sumaAp4." Se sumaron ".($i-1)." Números" ;

?>