<?php
//Ejercicio2:
echo "</br></br><strong>$Ap2</strong></br>";

$x=-3;
$y=15;

echo "Sumar $x+$y=".($x+$y);
?>
