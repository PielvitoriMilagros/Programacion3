<?php
//Clase 1

echo "<h1>Clase 1 </h1></br>";

//require "Enunciados.php";
include_once "Enunciados.php";
include_once "Ejer1.php";
include_once "Ejer2.php";
include_once "Ejer3.php";
include_once "Ejer4.php";
include_once "Ejer5.php";
include_once "Ejer6.php";
include_once "Ejer7.php";

?>