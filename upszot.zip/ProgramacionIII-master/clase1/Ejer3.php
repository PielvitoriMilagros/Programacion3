<?php 

//Ejercicio3:
echo "</br></br><strong>$Ap3</strong></br>";
echo "Sumar x=$x + y=$y=</br>".($x+$y);


?>