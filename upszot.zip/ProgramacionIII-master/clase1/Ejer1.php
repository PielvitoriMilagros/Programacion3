<?php 

//Ejercicio1:
echo "</br></br><strong>$Ap1</strong></br>";

$nombre="gonzalo";
$apellido="ferrer";

echo $nombre." ".$apellido;

?>