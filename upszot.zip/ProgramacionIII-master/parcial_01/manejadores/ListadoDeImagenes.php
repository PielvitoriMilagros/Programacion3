<?php

    echo "<font size='3' color='blue'  face='verdana' style='font-weight:bold' <br>Listar Pizzas <br> </font>";
    Pizzeria::ListarPizzas($_GET["tipo"]);

?>