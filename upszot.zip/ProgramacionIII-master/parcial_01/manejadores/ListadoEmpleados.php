<?php

    echo "<font size='3' color='blue'  face='verdana' style='font-weight:bold' <br>Listar Empleados <br> </font>";
    Pizzeria::ListarEmpleados($_GET["tipo"]);

?>