<?php 
//Parte POO

$Enunciado='
Enunciado: <br> 
Aplicaciones Nº ( producto conteiner) <br> 
Los containers puede ser (chico o grande) con una capacidad de 1000kg o 2500kg o 9000kg <br> <br> 
Los productos tiene un identificador  unico de producto, el nombre, el importador, el pais de origen y los kilos <br> 
Si el producto ya existe se suma los kilos <br> 


';


?>